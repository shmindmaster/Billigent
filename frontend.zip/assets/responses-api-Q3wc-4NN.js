import.meta?.env?.VITE_AZURE_OPENAI_RESPONSES_ENDPOINT;import.meta?.env?.VITE_AZURE_OPENAI_API_KEY;class a extends Error{constructor(e,t){super(e),this.code=t,this.name="ResponsesAPIError"}}async function n(s){return new Promise(e=>{setTimeout(()=>{e({success:!0,id:`response_${Date.now()}`,status:"completed",content:[{type:"text",text:`Based on the clinical evidence provided, I can help clarify the following regarding "${s}":

This appears to be a significant finding that could impact the case's documentation and coding. The clinical indicators suggest this diagnosis should be carefully considered for accurate DRG assignment.

Would you like me to elaborate on any specific aspect of this finding?`}],data:{response:`Mock response to: ${s}`,timestamp:new Date().toISOString()}})},1e3)})}async function o(s){return new Promise(e=>{setTimeout(()=>{e({success:!0,data:{id:s,status:"completed",result:"Analysis complete"}})},500)})}async function i(s){return new Promise(e=>{setTimeout(()=>{e({success:!0,data:{analysisId:`analysis_${Date.now()}`,status:"started"}})},100)})}export{a as R,o as a,n as g,i as s};
//# sourceMappingURL=responses-api-Q3wc-4NN.js.map
