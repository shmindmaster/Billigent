import{j as p}from"./ui-CAKCeI60.js";import{r as s}from"./vendor-azyNcgkC.js";const a=s.forwardRef(({className:r,...t},o)=>p.jsx("input",{ref:o,className:r,...t}));a.displayName="Input";export{a as I};
//# sourceMappingURL=input-D_7UgY-T.js.map
