import{j as o}from"./ui-CAKCeI60.js";import{c as n}from"./index-BdGiLShA.js";function a({className:r,size:s="md"}){const e={sm:"w-4 h-4",md:"w-6 h-6",lg:"w-8 h-8"};return o.jsx("div",{className:n("animate-spin rounded-full border-2 border-gray-300 border-t-blue-600",e[s],r)})}export{a as S};
//# sourceMappingURL=Spinner-LmD_BUG4.js.map
